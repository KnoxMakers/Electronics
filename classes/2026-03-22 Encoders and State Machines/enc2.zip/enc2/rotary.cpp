#include "rotary.h"

RotaryEncoder::RotaryEncoder(uint8_t pinA, uint8_t pinB) {
   _pinA = pinA;
   _pinB = pinB;
  _cumulativePosition = 0;
  _subStepCounter = 0;
  _state = 0;
}


void RotaryEncoder::begin() {
    pinMode(_pinA, INPUT_PULLUP);
    pinMode(_pinB, INPUT_PULLUP);

    // Initialize state
    _state = (digitalRead(_pinA) << 1) | digitalRead(_pinB);
}

void RotaryEncoder::update() {
    uint8_t pA = digitalRead(_pinA);
    uint8_t pB = digitalRead(_pinB);
    uint8_t currentState = (pA << 1) | pB;

    // Calculate index: [old_state_bits | new_state_bits]
    uint8_t index = ((_state & 0x03) << 2) | currentState;
    _subStepCounter += _transitionTable[index];

    // Logic for encoders resting on '11'
    if (currentState == 0b11) {
        if (_subStepCounter >= 4) {
           _cumulativePosition++;
        } else if (_subStepCounter <= -4) {
            _cumulativePosition--;
        }
        _subStepCounter = 0; // Reset at detent to clear noise
    }
    _state = currentState;
}

int RotaryEncoder::getPosition() {
    return _cumulativePosition;
}

void RotaryEncoder::reset() {
    _cumulativePosition = 0;
}

