#ifndef _ROTARY_H_INCLUDED_
#define _ROTARY_H_INCLUDED_

#include <Arduino.h>

class RotaryEncoder {
  private:
    uint8_t _pinA;
    uint8_t _pinB;
    volatile int _cumulativePosition;
    volatile int8_t _subStepCounter;
    volatile uint8_t _state;

    // The Gray Code Transition Table
    // 1 = CW, -1 = CCW, 0 = Invalid/Bounce
    const int8_t _transitionTable[16] = {
      0,  1, -1,  0,  // From 00
     -1,  0,  0,  1,  // From 01
      1,  0,  0, -1,  // From 10
      0, -1,  1,  0   // From 11
    };

  public:
    // Constructor
    RotaryEncoder(uint8_t pinA, uint8_t pinB);
    void begin();
    void update(); // This must be called from the ISR
    int getPosition();
    void reset();
};

#endif