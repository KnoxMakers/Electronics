#include "rotary.h"

int pinA = 15;
int pinB = 14;

// --- Global Instance ---
RotaryEncoder myEncoder(pinA, pinB);

// --- ISR Wrapper ---
// Since attachInterrupt needs a static function pointer, we use a wrapper
void encoderISR() {
  myEncoder.update();
}

void setup() {
  Serial.begin(115200);
  
  myEncoder.begin();

  // Attach the wrapper to both pins
  attachInterrupt(digitalPinToInterrupt(pinA), encoderISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(pinB), encoderISR, CHANGE);
}

void loop() {
  static int lastPos = 0;
  int currentPos = myEncoder.getPosition();

  if (currentPos != lastPos) {
    Serial.print("Cumulative Position: ");
    Serial.println(currentPos);
    lastPos = currentPos;
  }
}