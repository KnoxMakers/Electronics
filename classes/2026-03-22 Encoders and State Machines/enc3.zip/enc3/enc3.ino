#include "rotary.h"

int pinA = 15;
int pinB = 14;
int pinBtn = 13;

// --- Global Instance ---
// Config: Pins 2&4, Button on Pin 5, Reversed=true, Resolution=DETENT_ONLY
RotaryEncoder myEncoder(pinA, pinB, pinBtn, false, DETENT_ONLY);

// Hardware Timer callback for the Pico 2
struct repeating_timer timer;
  bool timer_callback(struct repeating_timer *t) {
  myEncoder.backgroundTick();
  return true; // Keep the timer running
}

// --- ISR Wrappers ---
void encoderISR() {
  myEncoder.update();
}
void buttonISR() {
  myEncoder.handleButton();
}

void setup() {
  Serial.begin(115200);

  myEncoder.begin();

  attachInterrupt(digitalPinToInterrupt(pinA), encoderISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(pinB), encoderISR, CHANGE);
  if (digitalPinToInterrupt(pinBtn) != -1) {
    attachInterrupt(digitalPinToInterrupt(pinBtn), buttonISR, CHANGE);
  }

  // Initialize a background timer to run every 10ms
  add_repeating_timer_ms(10, timer_callback, NULL, &timer);
}

void loop() {
  static int lastPos = 0;
  int currentPos = myEncoder.getPosition();
  if (currentPos != lastPos) {
    Serial.print("Position: "); Serial.println(currentPos);
    lastPos = currentPos;
  }

  ButtonEvent event = myEncoder.getButtonEvent();
  if (event != NONE) {
    switch(event) {
      case PRESSED:      Serial.println("Depressed"); break;
      case RELEASED:     Serial.println("Released");  break;
      case SINGLE_CLICK: Serial.println(">>> SINGLE CLICK"); break;
      case DOUBLE_CLICK: Serial.println(">>> DOUBLE CLICK"); break;
    }
  }
}