#ifndef _ROTARY_H_INCLUDED_
#define _ROTARY_H_INCLUDED_

#include <Arduino.h>
#include "pico/stdlib.h"

enum EncoderResolution {
  DETENT_ONLY = 4,  // some manual encoders pass through all 4 quadrature state on each detent
  FULL_STEP   = 1   // for applications where each transition is an event to be responded to
};

enum ButtonEvent {
  NONE,
  PRESSED,      // button has been depressed
  RELEASED,     // button was depressed and released
  SINGLE_CLICK, // button was pressed and released
  DOUBLE_CLICK  // timing for double click (between first release and second pressed)
};


class RotaryEncoder {
  private:
    uint8_t pinA_;
    uint8_t pinB_;
    uint8_t pinSW_;
    bool reversed_;
    EncoderResolution resolution_;
    
    volatile int cumulativePosition_ = 0;
    volatile int8_t subStepCounter_ = 0;
    volatile uint8_t state_ = 0;    // encoder state (00 01 10 11)
    
    // Button logic variables
    volatile ButtonEvent lastEvent_ = NONE;
    volatile bool lastHandledState_ = HIGH; // High = Not Pressed
    volatile unsigned long lastInterruptTime_ = 0;

    // Multi-click timing
    unsigned long clickWindow_ = 250;   // Max time between clicks for a double-click (ms)
    unsigned long debounceDelay_ = 30;  // time for debouncing on button press and release
    int clickCount_ = 0;
    unsigned long lastReleaseTime_ = 0;
    bool waitingForSecondClick_ = false;

    // Gray Code Transition Table
    // Index is [Previous 2 bits][Current 2 bits]
    const int8_t transitionTable_[16] = {
      0,  1, -1,  0,  // From 00
     -1,  0,  0,  1,  // From 01
      1,  0,  0, -1,  // From 10
      0, -1,  1,  0   // From 11
    };

  public:
    // Constructor
    RotaryEncoder(uint8_t pinA, uint8_t pinB, uint8_t pinSW = 255, bool reverse = false, EncoderResolution res = DETENT_ONLY, unsigned long clickWindow = 250) 
      : pinA_(pinA), pinB_(pinB), pinSW_(pinSW), reversed_(reverse), resolution_(res), clickWindow_(clickWindow),
        cumulativePosition_(0), subStepCounter_(0), state_(0) {}

    void begin();
    void update(); // This must be called from the ISR
    int getPosition() { return cumulativePosition_; }
    void handleButton();
    ButtonEvent getButtonEvent();
    void backgroundTick();
    void reset();
};



#endif