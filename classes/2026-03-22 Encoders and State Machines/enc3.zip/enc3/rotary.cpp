#include "rotary.h"

// Initiatlization of the encoder
void RotaryEncoder::begin() {
    pinMode(pinA_, INPUT_PULLUP);
    pinMode(pinB_, INPUT_PULLUP);
    if (pinSW_ != 255)
        pinMode(pinSW_, INPUT_PULLUP);
    state_ = (digitalRead(pinA_) << 1) | digitalRead(pinB_);
    lastHandledState_ = digitalRead(pinSW_);
}

// Called by an ISR when one of the encoder pins changes
void RotaryEncoder::update() {
    uint8_t currentState = (digitalRead(pinA_) << 1) | digitalRead(pinB_);
    uint8_t index = ((state_ & 0x03) << 2) | currentState;
    int8_t movement = transitionTable_[index];

    if (movement != 0) {
        int8_t adjustedMovement = reversed_ ? -movement : movement;
        subStepCounter_ += adjustedMovement;
        if (resolution_ == FULL_STEP) {
          cumulativePosition_ += adjustedMovement;
          subStepCounter_ = 0;
        } else if (currentState == 0b11) {
            if (subStepCounter_ >= (int8_t)resolution_)
                cumulativePosition_++;
            else if (subStepCounter_ <= -(int8_t)resolution_)
                cumulativePosition_--;
          subStepCounter_ = 0; 
        }
    }
    state_ = currentState;
}

// ISR for button press
void RotaryEncoder::handleButton() {
    unsigned long now = millis();
    if (now - lastInterruptTime_ < debounceDelay_) return;

    bool currentRead = digitalRead(pinSW_);
    if (currentRead != lastHandledState_) {
        lastHandledState_ = currentRead;
        lastInterruptTime_ = now;
        
        if (currentRead == LOW) { 
          lastEvent_ = PRESSED;
          clickCount_++;
          waitingForSecondClick_ = false; 
        } else { 
          lastEvent_ = RELEASED;
          lastReleaseTime_ = now;
          waitingForSecondClick_ = true;
        }
    }
}

// THis is a bacakground method for detecint double clicks
void RotaryEncoder::backgroundTick() {
    if (waitingForSecondClick_ && (millis() - lastReleaseTime_ > clickWindow_)) {
        if (clickCount_ == 1)
            lastEvent_ = SINGLE_CLICK;
        else if (clickCount_ >= 2)
            lastEvent_ = DOUBLE_CLICK;
        clickCount_ = 0;
        waitingForSecondClick_ = false;
    }
}

// Returns the event and resets the latch
ButtonEvent RotaryEncoder::getButtonEvent() {
      ButtonEvent temp = lastEvent_;
      lastEvent_ = NONE; 
      return temp;
}

