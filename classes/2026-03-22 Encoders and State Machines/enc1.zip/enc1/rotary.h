#ifndef _ROTARY_H_INCLUDED_
#define _ROTARY_H_INCLUDED_

#include <Arduino.h>

class RotaryEncoder {
  private:
    int pinA, pinB;
    int position;      // This only changes at a detent
    int accumulator;   // This tracks the raw quadrature steps
    int state;

    int encoderTable[16] = {
        0,  1, -1,  0, 
       -1,  0,  0,  1, 
        1,  0,  0, -1, 
        0, -1,  1,  0
    };

  public:
    RotaryEncoder(int a, int b);
    void init();
    void update();
    int getPosition();
};

#endif