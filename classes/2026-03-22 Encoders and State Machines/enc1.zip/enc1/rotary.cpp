#include "rotary.h"

RotaryEncoder::RotaryEncoder(int a, int b) {
    pinA = a;
    pinB = b;
    position = 0;
    accumulator = 0;
    state = 0;
}

void RotaryEncoder::init() {
    pinMode(pinA, INPUT_PULLUP);
    pinMode(pinB, INPUT_PULLUP);
    state = (digitalRead(pinA) << 1) | digitalRead(pinB);
}

void RotaryEncoder::update() {
    int currentPins = (digitalRead(pinA) << 1) | digitalRead(pinB);
    int index = ((state & 0x03) << 2) | (currentPins & 0x03);
    int movement = encoderTable[index];

    if (movement != 0) {
        accumulator += movement;
        state = currentPins;

        // detent logic: Only update the public position when we land on '11'
        if (state == 0b11) {

            // Determine direction based on the net movement since the last detent
            if (accumulator >= 2) position++;
            else if (accumulator <= -2) position--;
            
            accumulator = 0; // Reset for the next click
        }
    }
}

int RotaryEncoder::getPosition() {
    return position;
}