#include <Arduino.h>
#include "rotary.h"

// Create encoder instance using pins 14 and 15
RotaryEncoder myEncoder(15, 14);

void setup() {
    Serial.begin(115200);
    myEncoder.init();
}

int lastReported = 0;
void loop() {
    myEncoder.update();

    int current = myEncoder.getPosition();
    if (current != lastReported) {
        Serial.print("click: ");
        Serial.println(current);
        lastReported = current;
    }
}

